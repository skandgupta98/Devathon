<html>
<body>
<form action="welcome.php" method="post">
Name<input type="text" name="name"><br><br>
Password<input type="text" name="pwd"><br><br>
<input type="submit" name="submit" value="Login">
</body>
</form>
</html>